<!DOCTYPE html>
<html lang="en" dir="ltr">
  <head>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Singla Consulting Services</title>
    <link rel="shortcut icon" type="image/x-icon" href="assets/apple-touch-icon.png" />
    <link rel="stylesheet" href="assets/css/style.css">
    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap@5.2.0/dist/css/bootstrap.min.css">
  <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.2.0/dist/js/bootstrap.bundle.min.js"></script>
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/5.14.0/css/all.min.css">
  </head>
  <body>
<!--Navbar Starts-->
<nav class="navbar navbar-expand-lg ">
    <div class="container-fluid">
      <a class="navbar-brand" href="index.html"><span class="s1">Singla</span><span class="s2">Consulting Services</span></a>
      <button class="navbar-toggler" type="button" data-bs-toggle="collapse" data-bs-target="#navbarSupportedContent" aria-controls="navbarSupportedContent" aria-expanded="false" aria-label="Toggle navigation">
        <span class="navbar-toggler-icon"></span>
      </button>
      <div class="collapse navbar-collapse" id="navbarSupportedContent">
        <ul class="navbar-nav me-auto mb-2 mb-lg-0">
          <li class="nav-item dropdown">
            <a class="nav-link dropdown-toggle" href="#" role="button" data-bs-toggle="dropdown" aria-expanded="false">
              Online Services
            </a>
            <ul class="dropdown-menu">
              <li><a class="dropdown-item" href="#">Cloud Services</a></li>
              <li><a class="dropdown-item" href="#">Business Services</a></li>
              <li><a class="dropdown-item" href="#">Application Services</a></li>
              <li><a class="dropdown-item" href="#">Cyber Security</a></li>
              <li><a class="dropdown-item" href="#">Artificial Intelligence</a></li>
              <li><a class="dropdown-item" href="#">Intelligent Automation</a></li>
            </ul>
          </li>
        </ul>
        <form class="d-flex" role="search">
          <input class="form-control form1 me-2" type="search" placeholder="Search Services..." aria-label="Search">
          <button class="btn btn2 btn-outline-success me-5" type="submit"><i class="fas fa-search"></i></button>
        </form>
         <a href="signup.php"><button class="btn login btn-outline-success me-5" type="submit">Register</button></a>
         <!--<button onclick="myFunction()">Toggle dark mode</button>-->
      </div>
    </div>
  </nav>
<!--Navbar Ends-->


<div class="container1">
    <div class="content">
      <div class="left-side">
        <div class="address details">
          <i class="fas fa-map-marker-alt"></i>
          <div class="topic">Address</div>
          <div class="text-one">Singla consulting services kaithal Haryana , </div>
          <div class="text-two">huda Sector 19, building 93/19 Park-2 kaithal haryana -136027</div>
        </div>
        <div class="phone details">
          <i class="fas fa-phone-alt"></i>
          <div class="topic">Phone</div>
          <div class="text-one">98 1211 7635</div>
          <div class="text-two">70 1169 4287</div>
        </div>
        <div class="email details">
          <i class="fas fa-envelope"></i>
          <div class="topic">Email</div>
          <div class="text-one">singlaconsultancy1709@gmail.com</div>
          <div class="text-two">mohit.sk994@gmail.com</div>
        </div>
      </div>
      <div class="right-side">
        <div class="topic-text">Send us a message</div>
        <p>if you have any queries/suggestions please contact us.</p>
        <form action="contactcontroller.php" method="post">
          <div class="input-box">
            <input type="text" name="name" placeholder="Enter your name">
          </div>
          <div class="input-box">
            <input type="text" name="email" placeholder="Enter your email">
          </div>
          <div class="input-box message-box">
            <textarea name="description" placeholder="Enter your message"></textarea>
          </div>
          <div class="button">
            <input type="submit" value="Send Now" >
          </div>
        </form>
    </div>
    </div>
  </div>










<!--Footer starts-->
<footer>
  <div class="content">
    <div class="top">
      <div class="logo-details">
        <a class="navbar-brand" href="index.html"><span class="s1">Singla</span><span class="s2">Consulting Services</span></a>
      </div>
      <div class="media-icons">
        <a href="#"><i class="fab fa-facebook-f"></i></a>
        <a href="#"><i class="fab fa-twitter"></i></a>
        <a href="#"><i class="fab fa-instagram"></i></a>
        <a href="#"><i class="fab fa-linkedin-in"></i></a>
        <a href="#"><i class="fab fa-youtube"></i></a>
      </div>
    </div>
    <div class="link-boxes">
      <ul class="box">
        <li class="link_name">Company</li>
        <li><a href="index.html">Home</a></li>
        <li><a href="contact.html">Contact us</a></li>
        <li><a href="aboutus.html">About us</a></li>
        <li><a href="index.html">Get started</a></li>
      </ul>
      <ul class="box">
        <li class="link_name">Services</li>
        <li><a href="#">Cloud Services</a></li>
        <li><a href="#">Cyber Security</a></li>
        <li><a href="#">Customer Experience</a></li>
        <li><a href="#">Application Services</a></li>
        <li><a href="#">Business Excellence</a></li>
        <li><a href="#">Intelligent Automation</a></li>
        <li><a href="#">Enterprise Management</a></li>
      </ul>
      <ul class="box">
        <li class="link_name">Account</li>
        <li><a href="#">Profile</a></li>
        <li><a href="#">My account</a></li>
        <li><a href="#">Prefrences</a></li>
        <li><a href="#">Purchase</a></li>
      </ul>
      <ul class="box">
        <li class="link_name">Industries</li>
        <li><a href="#">Automative</a></li>
        <li><a href="#">Consumer Goods</a></li>
        <li><a href="#">Health Care</a></li>
        <li><a href="#">Insurance</a></li>
        <li><a href="#">Information Services</a></li>
        <li><a href="#">Life Science</a></li>
      </ul>
      <ul class="box input-box">
        <li class="link_name">Subscribe</li>
        <li><input type="text" placeholder="Enter your email"></li>
        <li><input type="button" value="Subscribe"></li>
      </ul>
    </div>
  </div>
  <hr>
  <div class="bottom-details">
    <div class="bottom_text">
      <span class="copyright_text">Copyright © 2022&nbsp;&nbsp; <a href="index.html">Singla Consultancy Services</a>All rights reserved</span>
      <span class="policy_terms">
        <a href="privacy.html">Privacy policy</a>
        <a href="terms_condition.html">Terms & condition</a>
      </span>
    </div>
  </div>
</footer>
  
<script src="assets/css/script.js"></script>
    </body>
  </html>
  
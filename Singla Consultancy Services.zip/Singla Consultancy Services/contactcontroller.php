<?php
	$link = mysqli_connect("localhost", "root", "", "shankar");
 
		// Check connection
		if($link === false){
		    die("ERROR: Could not connect. " . mysqli_connect_error());
		}
	if($_SERVER["REQUEST_METHOD"] == "POST") {

	$name = $_POST["name"];
	$email = $_POST["email"];
	$description = $_POST["description"];
}

	$sql = "INSERT INTO contactusquery ( name, email,description) VALUES ('$name' ,'$email','$description')";
	// $sql = "INSERT INTO users (name, email, mobile, password) VALUES ('$name','$email','$mobile','$password')";
	if(mysqli_query($link, $sql)){
    echo '<script>alert("Thanks query Submitted")</script>';

	} else{
    echo "ERROR: Could not able to execute $sql. " . mysqli_error($link);
	header('Location: index.php');
	}
 
mysqli_close($link);
?>

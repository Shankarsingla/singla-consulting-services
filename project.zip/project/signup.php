<!DOCTYPE html>
<html lang="en" dir="ltr">
  <head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link rel="stylesheet" href="https://unicons.iconscout.com/release/v4.0.0/css/line.css">
    <link rel="stylesheet" href="assets/css/login.css">
   </head>
<body>
  <div class="wrapper">
    <h2>Registration</h2>
    <form action="registercontroller.php" method="post">
      <div class="input-box">
        <input type="text" name="name" placeholder="Enter your name" required>
      </div>
      <div class="input-box">
        <input type="text" name="mobile" placeholder="Enter your Mobile no" required>
      </div>
      <div class="input-box">
        <input type="email" name="email"  placeholder="Enter your email" required>
      </div>
      <div class="input-box">
        <input type="password" name="password" class="password1" placeholder="Create password" required>
        <i class="uil uil-eye-slash showHidePw1"></i>
      </div>
      <div class="input-box">
        <input type="password" name="cpassword" class="password" placeholder="Confirm password" required>
        <i class="uil uil-eye-slash showHidePw"></i>
      </div>
      <div class="policy">
        <input type="checkbox">
        <h3> I accept all <a href="#" class="terms">terms & condition</a></h3>
      </div>
      <div class="input-box button">
        <input type="Submit" value="Register Now">
      </div>
      <div class="text">
        <h3>Already have an account? <a href="login.php">Login now</a></h3>
      </div>
    </form>
  </div>



  <script>
    const container = document.querySelector(".wrapper"),
      pwShowHide = document.querySelectorAll(".showHidePw"),
      pwShowHide1 = document.querySelectorAll(".showHidePw1"),
      pwFields = document.querySelectorAll(".password");
      pwFields1 = document.querySelectorAll(".password1");

    //show/hide password and change icon
    pwShowHide.forEach(eyeIcon =>{
        eyeIcon.addEventListener("click", ()=>{
            pwFields.forEach(pwField =>{
                if(pwField.type ==="password"){
                    pwField.type = "text";

                    pwShowHide.forEach(icon =>{
                        icon.classList.replace("uil-eye-slash", "uil-eye");
                    })
                }else{
                    pwField.type = "password";

                    pwShowHide.forEach(icon =>{
                        icon.classList.replace("uil-eye", "uil-eye-slash");
                    })
                }
            }) 
        })
    })
    pwShowHide1.forEach(eyeIcon =>{
        eyeIcon.addEventListener("click", ()=>{
            pwFields1.forEach(pwField =>{
                if(pwField.type ==="password"){
                    pwField.type = "text";

                    pwShowHide1.forEach(icon =>{
                        icon.classList.replace("uil-eye-slash", "uil-eye");
                    })
                }else{
                    pwField.type = "password";

                    pwShowHide1.forEach(icon =>{
                        icon.classList.replace("uil-eye", "uil-eye-slash");
                    })
                }
            }) 
        })
    })

   
  </script>

</body>
</html>
